/*
 * cruising_robot.c
 *
 * Created: 06.04.2018 23:20
 * Author: Bohdan Kopcak
 */

#include "asuro.h"
#include "sleepms.h"

int main(void)
{
	
/* First task
 * 
 * Robot is going to accelerate to its maximal speed and then slow down and stop.
 * Then it starts moving backwards same way.
 */

	Init();
	int max_speed = 255;

//Forward movement.
	MotorDir(FWD, FWD);
	
	//Acceleration.
	for (int i = 0; i < max_speed; i++)
	{
		MotorSpeed(i, i);
		sleepms(1);
	}
	
	
	//Maintaining speed for 1 second.
	MotorSpeed(max_speed, max_speed);
	sleepms(1000);
	
	//Deceleration.
	for (int i = (max_speed - 1); i > 0; i--)
	{
		MotorSpeed(i, i);
		sleepms(1);
	}

	sleepms(500);
	
	
//Backward movement.
	MotorDir(RWD, RWD);
	
	//Acceleration.
	for (int i = 0; i < max_speed; i++)
	{
		MotorSpeed(i, i);
		sleepms(1);
	}
		
	//Maintaining speed for 1 second.
	MotorSpeed(max_speed, max_speed);
	sleepms(1000);
		
	//Deceleration.
	for (int i = (max_speed - 1); i > 0; i--)
	{
		MotorSpeed(i, i);
		sleepms(1);
	}

	sleepms(500);
	
	//End of the first task.
	
/* Second task
 *
 * The robot repeats the same movement as in first task but with one motor only.
 * Firstly, it will use the right motor, then left. Robot stops himself by brake at the end.
 */

//Right wheel movement.
	MotorDir(FREE, FWD);
	
	//Acceleration.
	for (int i = 0; i < max_speed; i++)
	{
		MotorSpeed(0, i);
		sleepms(1);
	}
	
	//Maintaining speed for 1 second.
	MotorSpeed(0, max_speed);
	sleepms(1000);
	
	//Deceleration.
	for (int i = (max_speed - 1); i > 0; i--)
	{
		MotorSpeed(0, i);
		sleepms(1);
	}

	sleepms(500);
	
	
//Right wheel backward movement.
	MotorDir(FREE, RWD);
	
	//Acceleration.
	for (int i = 0; i < max_speed; i++)
	{
		MotorSpeed(0, i);
		sleepms(1);
	}
	
	//Maintaining speed for 1 second.
	MotorSpeed(0, max_speed);
	sleepms(1000);
	
	//Deceleration.
	for (int i = (max_speed - 1); i > 0; i--)
	{
		MotorSpeed(0, i);
		sleepms(1);
	}

	sleepms(500);
	
	
//Left wheel movement.
	MotorDir(FWD, FREE);

	//Acceleration.
	for (int i = 0; i < max_speed; i++)
	{
		MotorSpeed(i, 0);
		sleepms(1);
	}

	//Maintaining speed for 1 second.
	MotorSpeed(max_speed, 0);
	sleepms(1000);

	//Deceleration.
	for (int i = (max_speed - 1); i > 0; i--)
	{
		MotorSpeed(i, 0);
		sleepms(1);
	}

	sleepms(500);


//Left wheel backward movement.
	MotorDir(RWD, FREE);

	//Acceleration.
	for (int i = 0; i < max_speed; i++)
	{
		MotorSpeed(i, 0);
		sleepms(1);
	}

	//Maintaining speed for 1 second.
	MotorSpeed(max_speed, 0);
	sleepms(1000);

	//Deceleration.
	for (int i = (max_speed - 1); i > 0; i--)
	{
		MotorSpeed(i, 0);
		sleepms(1);
	}

	MotorDir(BREAK, BREAK);
	
	//End of the second task.
}