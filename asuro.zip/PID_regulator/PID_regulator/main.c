/*
 * PID_regulator.c
 *
 * Created: 28.05.2018 22:10:50
 * Author : Bohdan
 */ 

#include <avr/io.h>
#include "asuro.h"
#include "sleepms.h"

void iir (int *sensor);
void ChangeCounter(int *sensor);
void SpeedControl(void);

unsigned int OdoData[2];
unsigned int dif = 0;
unsigned int dist[2];
int v[2];
int P = 0;
int I = 0;
int D = 0;

int main(void)
{
	Init();
	MotorDir(FWD, FWD);
	MotorSpeed(200, 200);
    while (1) 
    {
		SpeedControl();
		MotorSpeed(v[0], v[1]);
    }
}

void iir (int *sensor)
{
	for (int i = 0; i < 2; i++)
	{
		lf[i] -= lf[i] >> 3;
		lf[i] += sensor[i] >> 3;
		sensor[i] -= lf[i];
	}
	
}

void ChangeCounter (int *sensor)
{
	for (int i = 0; i < 2; i++)
	{
		if (state[i] == HIGH && sensor[i] <= L_TRESHOLD){state[i] = LOW; dist[i] += 1;}
		else if (state[i] == LOW && sensor[i] >= H_THRESHOLD){state[i] = HIGH; dist[i] += 1;}
		
	}
	
}

void SpeedControl(int *sensor, char index)
{
	P = sesnsor[0] - sensor[1];
	I += P;
	D = P/memP
	P = memP
	a = P*0 + I*0 - D*0
	if (a > 0){}
}