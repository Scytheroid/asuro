/*
 * speedo.h
 *
 * Created: 28.05.2018 22:39
 * Author: Bohdan Kopcak
 */

#ifndef speedo_h
#define speedo_h

#include <avr/io.h>
#include "asuro.h"
#include "sleepms.h"

#define HIGH 0
#define H_THRESHOLD 812
#define LOW 1
#define L_TRESHOLD 212
#define LEFT 0
#define RIGHT 1

void iir (int *sensor);											 //Filters low frequency noise away.
void ChangeCounter (int *sensor);								 //Returns a true statement if a significant change in periodic input happens.
void int_to_string (unsigned int num, unsigned char *out);		 //Makes string out of int

#endif