/*
 * speedo.c
 *
 * Created: 18.05.2018 20:35:21
 * Author : Bohdan
 */ 

#include "speedo.h"

int lf[2];
unsigned char state[2];
unsigned char LitState = 0;
int odoValue[2];
int output[5];
int dist[2];

int speedo(void)
{
	ChangeCounter(odoValue);
		
	if (dist[1] > 320){ //Five spins of wheel * 8 spins of a gear for one spin of a wheel * 8 stripes on a wheel = 320
		LitState = 10;
		for (int i = 0; i < 2; i++){
			dist[i] = 0;
		}
	}
}

void ChangeCounter (int *sensor)
{	
	for (int i = 0; i < 2; i++)
	{	
		if (state[i] == HIGH && sensor[i] <= L_TRESHOLD){state[i] = LOW; dist[i] += 1;}	
		else if (state[i] == LOW && sensor[i] >= H_THRESHOLD){state[i] = HIGH; dist[i] += 1;}
		
	}
	
}