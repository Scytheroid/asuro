/*
 * obstacles.c
 *
 * Created: 01.05.2018 14:31:47
 * Author : Bohdan
 */ 

#include <avr/io.h>
#include "asuro.h"
#include "sleepms.h"

#define STATE_DRIVE 0
#define STATE_COLLISION 1
#define STATE_TURN 2

unsigned int timer = 0;
unsigned char state = STATE_DRIVE;
unsigned char isLeft = 0; //Is equal to 1 when expected to turn left


void doState(void);

int main(void)
{
	Init();
    while (1) 
    {
		doState();
		timer++;
		sleepms(100);
    }
	return 0;
}	

void doState()
{
	switch(state)
	{
		case STATE_DRIVE:
			StatusLED(GREEN);
			MotorDir(FWD, FWD);
			MotorSpeed(255, 255);
			if(PollSwitch())
			{
				MotorDir(BREAK, BREAK);
				MotorSpeed(0, 0);
				state = STATE_COLLISION;
				timer = 0;
			}
			if(timer > 20)
			{
				MotorDir(BREAK, BREAK);
				MotorSpeed(0, 0);
				state = STATE_TURN;
				timer = 0;
			}
			break;
		
		case STATE_COLLISION:
			StatusLED(RED);
			if(isLeft)
			{
				MotorDir(RWD, FREE);
				MotorSpeed(255, 0);	
			}
			else
			{
				MotorDir(FREE, RWD);
				MotorSpeed(0, 255);
			}
			if(timer > 10)
			{
				MotorDir(BREAK, BREAK);
				MotorSpeed(0, 0);
				state = STATE_DRIVE;
				isLeft ^= 1;
				timer = 0;
			}
			break;
			
		case STATE_TURN:
			StatusLED(YELLOW);
			if(isLeft)
			{
				MotorDir(RWD, FWD);
				MotorSpeed(255, 255);
			}
			else
			{
				MotorDir(FWD, RWD);
				MotorSpeed(255, 255);
			}
			if(timer > 10)
			{
				MotorDir(BREAK, BREAK);
				MotorSpeed(0, 0);
				state = STATE_DRIVE;
				isLeft ^= 1;
				timer = 0;
			}
			break;
	}
}