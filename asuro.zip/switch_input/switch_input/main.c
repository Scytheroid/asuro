/*
 * switch_input.c
 *
 * Created: 17.04.2018 7:03:35
 * Author : Bohdan Kopcak
 */ 

#include <avr/io.h>
#include "asuro.h"
#include "sleepms.h"

unsigned char btnload (unsigned char btnData, unsigned char i);

void main(void)
{
	Init();
	unsigned char btnData;	
	unsigned char index;
    while(1) 
    {
		for(unsigned char i = 0; i < 6; i++)
		{
			index = i + 49;
			SerWrite((&index), 1);
			if (btnload(PollSwitch(), i))
			{
				SerWrite(" zap ", 5);
			}
			else
			{
				SerWrite(" vyp ", 5);
			}
			
		}
		
		sleepms(100);
		SerWrite("\n\r", 2);
		
    }
	
}

unsigned char btnload (unsigned char btnData, unsigned char i)
{
	btnData &= 1 << i;
	return(btnData >> i);
}
