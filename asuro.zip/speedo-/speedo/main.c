/*
 * speedo.c
 *
 * Created: 18.05.2018 20:35:21
 * Author : Bohdan
 */ 

#include <avr/io.h>
#include "asuro.h"
#include "sleepms.h"

#define HIGH 0
#define H_THRESHOLD 10
#define LOW 1
#define L_TRESHOLD -10
#define LEFT 0
#define RIGHT 1


void iir (int *sensor);											 //Filters low frequency noise away.
void ChangeCounter (int *sensor);								 //Returns a true statement if a significant change in periodic input happens.
void int_to_string (unsigned int num, unsigned char *out);		 //Makes string out of int

int lf[2];
unsigned char state[2];
unsigned int LitState = 0;
int odoValue[2];
unsigned char output[5];
int dist[2];

int main(void)
{
    Init();
	StatusLED(OFF);
	MotorDir(FWD, FWD);
	MotorSpeed(200, 200);
    while (1) 
    {
		if(flag & ODOFLAG)
		{
			flag &= ~ODOFLAG;
			OdometrieData(odoValue);
			iir(odoValue);
			ChangeCounter(odoValue);
			if (dist[1] > 320) //Five spins of wheel * 8 spins of a gear for one spin of a wheel * 8 stripes on a wheel = 320
			{
				LitState = 20;
				for (int i = 0; i < 2; i++){dist[i] = 0;}	
			}
		}
		if (LitState)
		{
			LitState--; 
			StatusLED(GREEN);
		}
		else
		{
			StatusLED(OFF);
			}
	}
	
}

void iir (int *sensor)
{
	for (int i = 0; i < 2; i++)
	{
		lf[i] -= lf[i] >> 3;
		lf[i] += sensor[i] >> 3;
		sensor[i] -= lf[i];
		//int_to_string(sensor[i], output);
		//SerWrite(*output, 5);
	}
	
}

void ChangeCounter (int *sensor)
{	
	for (int i = 0; i < 2; i++)
	{	
		if ((state[i] == HIGH) && (sensor[i] <= L_TRESHOLD)){state[i] = LOW; dist[i] += 1;}	
		else if ((state[i] == LOW) && (sensor[i] >= H_THRESHOLD)){state[i] = HIGH; dist[i] += 1;}
		
	}
	
}

void int_to_string (unsigned int num, unsigned char *out)
{
	
	unsigned int ret = 0;
	unsigned int power = 10;
	
	if (num >= 0){out[4] = '+';} else {out[4] = '-';}
	for(int i = 5; i > 0; i--)
	{
		
		ret = num % power;
		num -= ret;
		out[(i - 1)] = (ret/(power/10)) + 48;
		power *= 10;
		
	}
}