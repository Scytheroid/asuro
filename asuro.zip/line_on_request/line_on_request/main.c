/*
 * line_on_request.c
 *
 * Created: 19.04.2018 18:10:28
 * Author : Bohdan Kopcak
 */ 

#include <avr/io.h>
#include "asuro.h"
#include "sleepms.h"

unsigned char btnLoad (unsigned char btnData, unsigned char i);
void int_to_string (unsigned int num, unsigned char *out);

int main(void)
{
	Init();
	
	unsigned int bfore = 0;
	unsigned char output[4];
	unsigned int odoData[2];

	
	while(1)
	{		
		if (btnLoad(PollSwitch(), 0) > bfore)
		{
			OdometrieData(odoData);
			SerWrite("Line:\tleva ", 11);
			int_to_string(odoData[0], output);
			SerWrite(output, 4);
			SerWrite("\tprava ", 6);
			int_to_string(odoData[1], output);
			SerWrite(output, 4);
			SerWrite("\n\r", 2);
			bfore = 1;
		}
		else if (btnLoad(PollSwitch(), 0) < bfore)
		{
			bfore = 0;
		}
		
	}

}

unsigned char btnLoad (unsigned char btnData, unsigned char i)
{
	btnData &= 1 << i;
	return(btnData >> i);
}

void int_to_string (unsigned int num, unsigned char *out)
{
	unsigned int ret = 0;
	unsigned int power = 10;
	
	for(unsigned int i = 4; i > 0; i--)
	{
		ret = num % power;
		num -= ret;
		out[(i - 1)] = (ret/(power/10)) + 48;
		power *= 10;
	}
	
}
