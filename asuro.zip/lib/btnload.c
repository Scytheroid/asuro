/*
 * btnload.c
 *
 * Created: 17.04.2018 08:38
 * Author: Bohdan Kopcak
 */

#include "btnload.h"

unsigned char btnload (unsigned char btnData, unsigned char i)
{
	btnData &= 1 << i;
	return(btnData >> i);
}
