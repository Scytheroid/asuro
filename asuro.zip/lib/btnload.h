/*
 * btnload.h
 *
 * Created: 17.04.2018 08:38
 * Author: Bohdan Kopcak
 */

#ifndef btnload_h
#define btnload_h

//This function takes an output of PollSwitch() and depending on argument it returns a value of a chosen bit.

uint8_t btnload(uint8_t btnData, uint8_t i)

#endif