/*
 * cruising_robot.c
 *
 * Created: 06.04.2018 23:20
 * Author: Bohdan Kopcak
 */

#include "asuro.c"
#include "sleepms.h"

int main(void)
{
	
/* First task
 * 
 * Robot is going to accelerate to its maximal speed and then slow down and stop.
 * Then it starts moving backwards same way.
 */

//Forward movement.
	MotorDir(FWD, FWD);
	
	//Acceleration.
	MotorSpeed(160, 160);
	sleepms(200);
	MotorSpeed(190, 190);
	sleepms(200);
	MotorSpeed(220, 220);
	sleepms(100);
	
	//Maintaining speed for 1 second.
	MotorSpeed(255, 255);
	sleepms(1000);
	
	//Deceleration.
	MotorSpeed(220, 220);
	sleepms(100);
	MotorSpeed(190, 190);
	sleepms(200);
	MotorSpeed(160, 160);
	sleepms(200);
	MotorSpeed(FREE, FREE);
	sleepms(500);
	
	
//Backward movement.
	MotorDir(RWD, RWD);
	
	//Acceleration.
	MotorSpeed(160, 160);
	sleepms(200);
	MotorSpeed(190, 190);
	sleepms(200);
	MotorSpeed(220, 220);
	sleepms(100);
		
	//Maintaining speed for 1 second.
	MotorSpeed(255, 255);
	sleepms(1000);
		
	//Deceleration.
	MotorSpeed(220, 220);
	sleepms(100);
	MotorSpeed(190, 190);
	sleepms(200);
	MotorSpeed(160, 160);
	sleepms(200);
	MotorSpeed(FREE, FREE);
	sleepms(500);
	
	//End of the first task.
	
/* Second task
 *
 * The robot repeats the same movement as in first task but with one motor only.
 * Firstly, it will use the right motor, then left. Robot stops himself by brake at the end.
 */

//Right wheel movement.
	MotorDir(FWD, FWD);
	
	//Acceleration.
	MotorSpeed(BREAK, 160);
	sleepms(200);
	MotorSpeed(BREAK, 190);
	sleepms(200);
	MotorSpeed(BREAK, 220);
	sleepms(100);
	
	//Maintaining speed for 1 second.
	MotorSpeed(BREAK, 255);
	sleepms(1000);
	
	//Deceleration.
	MotorSpeed(BREAK, 220);
	sleepms(100);
	MotorSpeed(BREAK, 190);
	sleepms(200);
	MotorSpeed(BREAK, 160);
	sleepms(200);
	MotorSpeed(BREAK, FREE);
	sleepms(500);
	
	
//Right wheel backward movement.
	MotorDir(RWD, RWD);
	
	//Acceleration.
	MotorSpeed(BREAK, 160);
	sleepms(200);
	MotorSpeed(BREAK, 190);
	sleepms(200);
	MotorSpeed(BREAK, 220);
	sleepms(100);
	
	//Maintaining speed for 1 second.
	MotorSpeed(BREAK, 255);
	sleepms(1000);
	
	//Deceleration.
	MotorSpeed(BREAK, 220);
	sleepms(100);
	MotorSpeed(BREAK, 190);
	sleepms(200);
	MotorSpeed(BREAK, 160);
	sleepms(200);
	MotorSpeed(BREAK, FREE);
	sleepms(500);
	
	
//Left wheel movement.
	MotorDir(FWD, FWD);

	//Acceleration.
	MotorSpeed(160, BREAK);
	sleepms(200);
	MotorSpeed(190, BREAK);
	sleepms(200);
	MotorSpeed(220,BREAK);
	sleepms(100);

	//Maintaining speed for 1 second.
	MotorSpeed(255,BREAK);
	sleepms(1000);

	//Deceleration.
	MotorSpeed(220, BREAK);
	sleepms(100);
	MotorSpeed(190, BREAK);
	sleepms(200);
	MotorSpeed(160, BREAK);
	sleepms(200);
	MotorSpeed(FREE, BREAK);
	sleepms(500);


//Left wheel backward movement.
	MotorDir(RWD, RWD);

	//Acceleration.
	MotorSpeed(160, BREAK);
	sleepms(200);
	MotorSpeed(190, BREAK);
	sleepms(200);
	MotorSpeed(220, BREAK);
	sleepms(100);

	//Maintaining speed for 1 second.
	MotorSpeed(255, BREAK);
	sleepms(1000);

	//Deceleration.
	MotorSpeed(220, BREAK);
	sleepms(100);
	MotorSpeed(190, BREAK);
	sleepms(200);
	MotorSpeed(160, BREAK);
	sleepms(200);
	MotorSpeed(BREAK, BREAK);
	
	//End of the second task.
}