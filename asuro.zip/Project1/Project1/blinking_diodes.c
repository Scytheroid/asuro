/*
 * blinking_diodes.c
 *
 * Created: 06.04.2018 22:10
 * Author: Bohdan Kopcak
 */

#include "asuro.c"
#include "sleepms.h"

int main(void) 
{
	Init();
	int x = 0;
	while (x == 0)
	{
		//Flashing of rear LED diodes.
		BackLED(OFF, ON);
		sleepms(1000);
		BackLED(ON, OFF);
		sleepms(1000);
		BackLED(OFF, ON);
		sleepms(1000);
		BackLED(ON, OFF);
		sleepms(1000);
		BackLED(OFF, ON);
		sleepms(1000);
		BackLED(ON, OFF);
		sleepms(1000);
		BackLED(OFF, OFF);
		
		//Lighting up status LED.
		StatusLED(RED);
		sleepms(1000);
		StatusLED(YELLOW);
		sleepms(1000);
		StatusLED(GREEN);
		sleepms(1000);
		StatusLED(OFF);
		
		//Flashing of front LED diode.
		FrontLED(ON);
		sleepms(1000);
		FrontLED(OFF);
		sleepms(1000);
		FrontLED(ON);
		sleepms(1000);
		FrontLED(OFF);
		sleepms(1000);
		FrontLED(ON);
		sleepms(1000);
		FrontLED(OFF);
		sleepms(1000);
	}	
	
}
