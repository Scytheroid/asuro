/*
 * Project1.c
 *
 * Created: 3. 4. 2014 20:42:10
 *  Author: Marek
 */ 


#include <avr/interrupt.h>
#include "asuro.c"

void sleepms(int ms);

int main(void)
{
	Init();
    //Zkontroluje vsechny LEDky
	StatusLED(GREEN); //Rozsviti status LED zelene
    sleepms(1000); //Pocka 1 sekundu
    StatusLED(YELLOW); //Rozsviti status LED zlute
    sleepms(1000); //Pocka 1 sekundu
    StatusLED(RED); //Rozsviti status LED cervene
    sleepms(1000); //Pocka 1 sekundu
    StatusLED(OFF); //Zhasne status LED

    sleepms(1000); //Pocka 1 sekundu

    BackLED(ON,OFF); //Rozsviti levou zadni LED
    sleepms(1000); //Pocka 1 sekundu
    BackLED(ON,ON); //Rozsviti obe zadni LED
    sleepms(1000); //Pocka 1 sekundu
    BackLED(OFF,ON); //Rozsviti pravou zadni LED
    sleepms(1000); //Pocka 1 sekundu
    BackLED(OFF,OFF); //Zhasne zadni LED

    sleepms(1000); //Pocka 1 sekundu

    FrontLED(ON); //Rozsviti predni LED
    sleepms(1000); //Pocka 1 sekundu
    FrontLED(OFF); //Zhasne predni LED

    //Motory
    MotorDir(FWD,FWD); //Nastavy smer motoru dopredu
    MotorSpeed(255,255); //Rozjede motory na plnou rychlost
    sleepms(1000); //Pocka 1 sekundu
    MotorSpeed(128,255); //Levy motor pojede na polovinu
    sleepms(1000); //Pocka 1 sekundu
    MotorDir(RWD,FREE); //Levy motor couva, pravy volny
    sleepms(1000); //Pocka 1 sekundu
    MotorDir(BREAK,BREAK); //Brzdi obema motory

    //Seriova linka
    SerWrite("ASURO funguje!",14); //Vypise text
    unsigned char zprava[12]="Ahoj svete!"; //Definice pomoci ""
    SerWrite(zprava,11); //Vypise text
    unsigned char text[6]={'a','s','u','r','o','\n'}; //Definice pomoci {}
    SerWrite(text,6); //Vypise text
 }


void sleepms(int ms){ //Uspi kontroler na ms milisekund
	Sleep(1); //Vyuzije funkci z asuro.h, ktera uspava na 1/72000 s
}