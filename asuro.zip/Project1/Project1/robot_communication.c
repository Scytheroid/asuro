/*
 * robot_communication.c
 *
 * Created: 07.04.2018 00:40
 * Author: Bohdan Kopcak
 */

#include "asuro.c"
#include "sleepms.h"

int main(void)
{
	int ln = 9;
	int interval = 1000;
	int i = 0;
	while (i == 0)
	{
		SerWrite("ASURO! 0\n", ln);
		sleepms(interval);
		SerWrite("ASURO! 1\n", ln);
		sleepms(interval);
		SerWrite("ASURO! 2\n", ln);
		sleepms(interval);
		SerWrite("ASURO! 3\n", ln);
		sleepms(interval);
		SerWrite("ASURO! 4\n", ln);
		sleepms(interval);
		SerWrite("ASURO! 5\n", ln);
		sleepms(interval);
		SerWrite("ASURO! 6\n", ln);
		sleepms(interval);
		SerWrite("ASURO! 7\n", ln);
		sleepms(interval);
		SerWrite("ASURO! 8\n", ln);
		sleepms(interval);
		SerWrite("ASURO! 9\n", ln);
		sleepms(interval);
	}

}