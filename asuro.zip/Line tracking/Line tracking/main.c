/*
 * Line tracking.c
 *
 * Created: 05.06.2018 7:14:12
 * Author : Bohdan
 */ 

#include <avr/io.h>
#include "asuro.h"
#include "sleepms.h"


int main(void)
{
	Init();
	unsigned int LineON[2];
	unsigned int LineOFF[2];
    while (1) 
    {
		int LineON[2];
		int LineOFF[2];
		FrontLED(ON);
		LineData(LineON);
		FrontLED(OFF);
		LineData(LineOFF);
		
    }
}


