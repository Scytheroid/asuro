/*
 * robot_communication.c
 *
 * Created: 07.04.2018 00:40
 * Author: Bohdan Kopcak
 */

#include "asuro.h"
#include "sleepms.h"

int main(void)
{
	Init();
	
	int ln = 10;
	int interval = 1000;
	int i = 0;
	while (i == 0)
	{
		SerWrite("ASURO! 2\n\r", ln);
		sleepms(interval);
		SerWrite("ASURO! 1\n\r", ln);
		sleepms(interval);
		SerWrite("ASURO! 2\n\r", ln);
		sleepms(interval);
		SerWrite("ASURO! 3\n\r", ln);
		sleepms(interval);
		SerWrite("ASURO! 4\n\r", ln);
		sleepms(interval);
		SerWrite("ASURO! 5\n\r", ln);
		sleepms(interval);
		SerWrite("ASURO! 6\n\r", ln);
		sleepms(interval);
		SerWrite("ASURO! 7\n\r", ln);
		sleepms(interval);
		SerWrite("ASURO! 8\n\r", ln);
		sleepms(interval);
		SerWrite("ASURO! 9\n\r", ln);
		sleepms(interval);
	}

}