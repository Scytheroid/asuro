/*
 * sleepms.h
 *
 * Created: 07.04.2018 09:13
 * Author: Bohdan Kopcak
 */

#ifndef sleepms_h
#define sleepms_h

// Transforms Sleep function of asuro.h which makes the system wait for 1/36k second into n-times one millisecond.

void sleepms(int ms);

#endif