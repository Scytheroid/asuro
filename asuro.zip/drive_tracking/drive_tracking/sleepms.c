/*
 * sleepms.h
 *
 * Created: 06.04.2018 23:20
 * Author: Bohdan Kopcak
 */

#include "sleepms.h"
#include "asuro.h"

// Transforms Sleep function of asuro.h which makes the system wait for 1/72k second into n-times one millisecond.

void sleepms(int ms)
{
	for(int i = 0; i < ms; i++)
	{
		Sleep(72);
	}
	
}