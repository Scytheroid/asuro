/*
 * drive_tracking.c
 *
 * Created: 18.04.2018 18:11:55
 * Author : Bohdan
 */ 

#include <avr/io.h>
#include "asuro.h"
#include "sleepms.h"

void int_to_string (unsigned int num, unsigned char *out);

int main(void)
{
	Init();
	unsigned int odoData[2];
	unsigned int lineData[2];
	unsigned char out[4];
	
    while (1) 
    {
		OdometrieData(odoData);
		LineData(lineData);
		SerWrite("Odom:\tleft ", 11);
		int_to_string(odoData[0], out);
		SerWrite(out, 4);
		SerWrite("\tright ", 7);
		int_to_string(odoData[1], out);
		SerWrite(out, 4);
		SerWrite("\n\r", 2);
		SerWrite("Line:\tleft ", 11);
		int_to_string(lineData[0], out);
		SerWrite(out, 4);
		SerWrite("\tright ", 7);
		int_to_string(lineData[1], out);
		SerWrite(out, 4);
		SerWrite("\n\r\n", 3);
		sleepms(500);
    }
	
}

void int_to_string (unsigned int num, unsigned char *out)
{
	unsigned int ret = 0;
	unsigned int power = 10;
	
	for(unsigned int i = 4; i > 0; i--)
	{
		ret = num % power;
		num -= ret;
		out[(i - 1)] = (ret/(power/10)) + 48;
		power *= 10;
	}
	
}